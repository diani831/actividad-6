


$('#parrafo').css("background", "white")

$('.mensaje').css("font-size", "80px").css("background", "white")

$('#DESCRIPCIÓN').click(function(){
    $(this).css("font-size", "50px")
})

$('#PLANETA').click(function(){
    $(this).css("font-size", "50px")
})

$('#NINOS').click(function(){
    $(this).css("font-size", "50px")
})

$('#ELJUEGO').click(function(){
    $(this).css("font-size", "50px")
})

$('#SUPERHEORES').click(function(){
    $(this).css("font-size", "50px")
})
$('#DOCENTES').click(function(){
    $(this).css("font-size", "50px")
})
$('#PADRES').dblclick(function(){
    $(this).css("color", "red")
})

$('#ESCUELA').click(function(){
    $(this).css("font-size", "50px")
})

$('#ENTORNO SOCIAL').click(function(){
    $(this).css("font-size", "50px")
})

$('#MODELOS').click(function(){
    $(this).css("font-size", "50px")
})


$('li').mouseover(function(){
     $(this).css("background", "pink")
    })

$('div').mouseout(function(){
    $(this).css("background", "red")
})
